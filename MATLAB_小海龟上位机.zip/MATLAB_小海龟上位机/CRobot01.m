classdef CRobot01 < handle
    properties
        x               %机器人横坐标
        y               %机器人纵坐标
        Obstacle_R      %避障半径
        k1              %C不满足时，速度控制因子
        vx
        vy
        k               %入轨速度控制因子
        h               %animatedline为创建动画线条
          %目标的纵坐标        
    end
    properties(Dependent)
        xo               %以目标为原点时，机器人的相对横坐标
        yo               %以目标为原点时，机器人的相对纵坐标
        vt               %机器人和目标连线上，指向轨迹的速度
        vr               %环绕速度，垂直于vt
        r                %机器人到目标的距离
        th               %机器人与目标连线与X轴的夹角
        
    end
    
    methods
        function obj = CRobot01()
            obj.x = 0;
            obj.y = 0;
            obj.Obstacle_R = 2;               %避障半径
            obj.k1 = 5;
            obj.vx = 0;
            obj.vy = 0;
            obj.k = 0.02;
            obj.h  = animatedline;        %animatedline为创建动画线条

            
        end
        
        %Dependent 属性的计算公式要放在get方法中

        %计算入轨速度
        %计算环绕速度

        %计算机器人当前位置与X轴的夹角
        function th = get.th(obj)
            if (obj.xo >= 0)                    %第一、四象限
                th = atan(obj.yo / obj.xo);
            else                                %第二、三象限
                th = pi + atan(obj.yo / obj.xo);
            end
           
        end
             
    end
end