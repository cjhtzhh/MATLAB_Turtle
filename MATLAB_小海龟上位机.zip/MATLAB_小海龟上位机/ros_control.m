function varargout = ros_control(varargin)
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @ros_control_OpeningFcn, ...
                   'gui_OutputFcn',  @ros_control_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end



% --- Executes just before ros_control is made visible.
function ros_control_OpeningFcn(hObject, eventdata, handles, varargin)
% 声明一些全局变量
% ROS Master URI和Topic name
global rosMasterUri;
global teleopTopicName;

%------------------------Cover01t.m程序初始化参数----------------------------
pos = [0 0 11 11];        %[x y w h]
h = rectangle('Position',pos);
h.LineWidth = 2;
%画长方形必不可少的语句，没有就无法显示。
axis([0 11 0 11]);
axis equal;
ax = gca;
ax.XMinorTick = 'on';        ax.YMinorTick = 'on';
ax.XMinorGrid = 'on';        ax.YMinorGrid = 'on';
hold off

rosMasterUri = 'http://172.22.120.114:11311';
teleopTopicName = '/turtle1/cmd_vel';
% rosMasterUri = 'http://192.168.0.100:11311';
% teleopTopicName = '/cmd_vel';

% 机器人的运行速度
global leftVelocity
global rightVelocity
global forwardVelocity
global backwardVelocity

leftVelocity = 1.0;       % 角速度 (rad/s)
rightVelocity = -1.0;      % 角速度 (rad/s)
forwardVelocity = 1.0;     % 线速度 (m/s)
backwardVelocity = -1.0;    % 线速度 (m/s)
% Choose default command line output for ros_control
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);

% UIWAIT makes ros_control wait for user response (see UIRESUME)
% uiwait(handles.figure1);


% --- Outputs from this function are returned to the command line.
function varargout = ros_control_OutputFcn(hObject, eventdata, handles) 
varargout{1} = handles.output;



function URIEdit_Callback(hObject, eventdata, handles)
% hObject    handle to URIEdit (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rosMasterUri
rosMasterUri = get(hObject,'String')
% Hints: get(hObject,'String') returns contents of URIEdit as text
%        str2double(get(hObject,'String')) returns contents of URIEdit as a double


% --- Executes during object creation, after setting all properties.
function URIEdit_CreateFcn(hObject, eventdata, handles)

if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function cmd_vel_Callback(hObject, eventdata, handles)
% hObject    handle to cmd_vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global teleopTopicName
teleopTopicName = get(hObject,'String')
% Hints: get(hObject,'String') returns contents of cmd_vel as text
%        str2double(get(hObject,'String')) returns contents of cmd_vel as a double


% --- Executes during object creation, after setting all properties.
function cmd_vel_CreateFcn(hObject, eventdata, handles)
% hObject    handle to cmd_vel (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pose_Callback(hObject, eventdata, handles)
% hObject    handle to pose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global rosPose
rosPose = get(hObject,'String')
% Hints: get(hObject,'String') returns contents of pose as text
%        str2double(get(hObject,'String')) returns contents of pose as a double


% --- Executes during object creation, after setting all properties.
function pose_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pose (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

% --- Executes on button press in connect.
function connect_Callback(hObject, eventdata, handles)
% hObject    handle to connect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global rosMasterUri
global teleopTopicName
global robot
global velmsg
global posesub
global posedata

setenv('ROS_MASTER_URI',rosMasterUri)
rosinit
robot = rospublisher(teleopTopicName,'geometry_msgs/Twist');   %发布小海龟的速度信息
posesub = rossubscriber('/turtle1/pose');                      %订阅小海龟的pose信息 
velmsg = rosmessage(robot);
posedata = receive(posesub);        %接受ROS端发来的pose


% --- Executes on button press in disconnect.
function disconnect_Callback(hObject, eventdata, handles)
% hObject    handle to disconnect (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
rosshutdown

% --- Executes on button press in go.
function go_Callback(hObject, eventdata, handles)
% hObject    handle to go (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global velmsg
global robot
global forwardVelocity
global posesub
global posedata

velmsg.Angular.Z = 0;
velmsg.Linear.X = forwardVelocity;
send(robot,velmsg);
posedata = receive(posesub);        %接受ROS端发来的pose
set(handles.pose_x,'String',posedata.X);
set(handles.pose_y,'String',posedata.Y);

% --- Executes on button press in right.
function right_Callback(hObject, eventdata, handles)
% hObject    handle to right (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global velmsg
global robot
global rightVelocity
global posesub
global posedata

velmsg.Angular.Z = rightVelocity;
velmsg.Linear.X = 0;
send(robot,velmsg);
posedata = receive(posesub);        %接受ROS端发来的pose
set(handles.pose_x,'String',posedata.X);
set(handles.pose_y,'String',posedata.Y);

% --- Executes on button press in back.
function back_Callback(hObject, eventdata, handles)
% hObject    handle to back (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global velmsg
global robot
global backwardVelocity
global posesub
global posedata

velmsg.Angular.Z = 0;
velmsg.Linear.X = backwardVelocity;
send(robot,velmsg);
posedata = receive(posesub);        %接受ROS端发来的pose
set(handles.pose_x,'String',posedata.X);
set(handles.pose_y,'String',posedata.Y);

function stop_Callback(hObject, eventdata, handles)
% hObject    handle to stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global velmsg
global robot
global posesub
global posedata

velmsg.Angular.Z = 0;
velmsg.Linear.X = 0;
send(robot,velmsg);
posedata = receive(posesub);        %接受ROS端发来的pose
set(handles.pose_x,'String',posedata.X);
set(handles.pose_y,'String',posedata.Y);

% --- Executes on button press in left.
function left_Callback(hObject, eventdata, handles)
% hObject    handle to left (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global velmsg
global robot
global leftVelocity
global posesub
global posedata

velmsg.Angular.Z = leftVelocity;
velmsg.Linear.X = 0;
send(robot,velmsg);
posedata = receive(posesub);        %接受ROS端发来的pose
set(handles.pose_x,'String',posedata.X);
set(handles.pose_y,'String',posedata.Y);

% --- Executes during object creation, after setting all properties.
function pose_x_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pose_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% global posedata
% global pose_x
% 
% pose_x = set(hObject,'String',posedata.X);
% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function pose_x_Callback(hObject, eventdata, handles)
% hObject    handle to pose_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pose_x as text
%        str2double(get(hObject,'String')) returns contents of pose_x as a double


% --- Executes on button press in stop.


% --- If Enable == 'on', executes on mouse press in 5 pixel border.
% --- Otherwise, executes on mouse press in 5 pixel border or over pose_x.

function pose_x_ButtonDownFcn(hObject, eventdata, handles)
% hObject    handle to pose_x (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)


function pose_y_Callback(hObject, eventdata, handles)
% hObject    handle to pose_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pose_y as text
%        str2double(get(hObject,'String')) returns contents of pose_y as a double


% --- Executes during object creation, after setting all properties.
function pose_y_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pose_y (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function pose_Theta_Callback(hObject, eventdata, handles)
% hObject    handle to pose_Theta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of pose_Theta as text
%        str2double(get(hObject,'String')) returns contents of pose_Theta as a double


% --- Executes during object creation, after setting all properties.
function pose_Theta_CreateFcn(hObject, eventdata, handles)
% hObject    handle to pose_Theta (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end




% --- Executes on button press in ADplot.
function togglebutton4_Callback(hObject, eventdata, handles)
% hObject    handle to ADplot (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of ADplot


% --- Executes on button press in run_stop.


% --- Executes on button press in trajectory.
function trajectory_Callback(hObject, eventdata, handles)
% hObject    handle to trajectory (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hint: get(hObject,'Value') returns toggle state of trajectory



function edit14_Callback(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit14 as text
%        str2double(get(hObject,'String')) returns contents of edit14 as a double


% --- Executes during object creation, after setting all properties.
function edit14_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit14 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit15_Callback(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit15 as text
%        str2double(get(hObject,'String')) returns contents of edit15 as a double


% --- Executes during object creation, after setting all properties.
function edit15_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit15 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit16_Callback(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit16 as text
%        str2double(get(hObject,'String')) returns contents of edit16 as a double


% --- Executes during object creation, after setting all properties.
function edit16_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit16 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit11_Callback(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit11 as text
%        str2double(get(hObject,'String')) returns contents of edit11 as a double


% --- Executes during object creation, after setting all properties.
function edit11_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit11 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit13_Callback(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit13 as text
%        str2double(get(hObject,'String')) returns contents of edit13 as a double


% --- Executes during object creation, after setting all properties.
function edit13_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit13 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end



function edit12_Callback(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Hints: get(hObject,'String') returns contents of edit12 as text
%        str2double(get(hObject,'String')) returns contents of edit12 as a double


% --- Executes during object creation, after setting all properties.
function edit12_CreateFcn(hObject, eventdata, handles)
% hObject    handle to edit12 (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end

function ADplot_Callback(hObject, eventdata, handles)
global velmsg
global robot
global posesub
global posedata
global Run_Stop;
global Control_Auto;
if get(hObject,'value')
    set(handles.run_stop, 'String','运行');  %设置本按钮文本为“关闭串口”
    %set(handles.Pattern, 'String','自主');  %设置本按钮文本为“关闭串口”
    Run_Stop = 1;
    %Control_Auto = 1;
    Control_flag = 0;
    velmsg.Linear.X = 0 ;
    velmsg.Linear.Y = 0 ;
    velmsg.Angular.Z = 0;
    %%----------------------------1、建立智能群体----------------------------------
    %---------------（1）设置智能体的数量-----------------
    M = 1;                  %小海龟个数
    V = 3;
    Th = randi([-3 3], 1, M);
    robot = rospublisher('/turtle1/cmd_vel',rostype.geometry_msgs_Twist);  %发布小海龟的速度信息
    posesub = rossubscriber('/turtle1/pose');                               %订阅小海龟的pose信息
    posedata = receive(posesub);        %接受ROS端发来的pose
    
    velmsg = rosmessage(robot);        %得到ROS端的速度信息
    velmsg.Linear.X = V * cos(Th);             %线速度x
    velmsg.Linear.Y = V * sin(Th);             %线速度y
    %cmdmsg.Angular.Z = 1;              %角速度z
    
    %---------------（2）用缺省值生成一个对象数组-----------------
    f(1,M) = CRobot01();  % 创建m个智能体
    
    for m = 1:M
        %设定第i个智能体的初始位置
        f(m).x = posedata.X;
        f(m).y = posedata.Y; 
        f(m).vx = double(velmsg.Linear.X);
        f(m).vy = double(velmsg.Linear.Y);
        axis equal
    end
    
    %----------------------(3)设置智能体的运动标记--------------------------
    hold on;
    p = plot(0,0);
    xlabel('X(m)');    ylabel('Y(m)'); 
    for i = 1:M
        p(i) = plot(f(i).x,f(i).y,'o','MarkerFaceColor','blue');

        %设置智能体的运动轨迹,
        %f(i).h = animatedline('MaximumNumPoints',20);      %创建一个动态线条对象，非常重要
        f(i).h = animatedline;      %创建一个动态线条对象，非常重要
        f(i).h.Color = 'Blue';
        f(i).h.LineStyle = ':';
        f(i).h.LineWidth = 1;
    end
%---------------------------2、建立任务区域----------------------------------
    %设置边界参数
    Eleft = -0.1;      Eright = 11.1;     W = Eright - Eleft;
    Ebottom = -0.1;    Etop = 11.1;       H = Etop - Ebottom;
    %设置网格大小dL
    dL = 0.2;

    %设置网格中心点的位置及存储数组
    x0 = Eleft+dL/2 : dL: Eright-dL/2;       
    y0 = Ebottom+dL/2 : dL : Etop-dL/2;
    Lz = length(x0);

    [X0,Y0] = meshgrid(x0,y0); 
    C = zeros(size(X0));           %用于存储各个网格的有效覆盖值。例c = zeros(5)表示得到一个5*5的零矩阵。

    pos = [0 0 11 11];        %[x y w h]
    h = rectangle('Position',pos);
    h.LineWidth = 2;
    %画长方形必不可少的语句，没有就无法显示。
    axis([0 11 0 11]);
    axis equal;

    ax = gca;                                              %绘制图网格
    ax.XMinorTick = 'on';        ax.YMinorTick = 'on';
    ax.XMinorGrid = 'on';        ax.YMinorGrid = 'on';
    hold off    
%---------------------------3、设置模拟运动采样的参数----------------------------------
    %---------------（1）设置采样时间及点数-----------------
    dt = 0.1;           %采样间隔时间0.1s
    t = 500;            %仿真计算的总时间200s
    T = t/dt;           %采样点数
    %---------------（2）初始化智能体的速度存储数组-----------------
    X1 = zeros(M, T);    Y1 = zeros(M, T);              %zeros(2,8)表示二行八列的零矩阵
    %----------------------5、全部智能体的实时运动状态控制--------------------------
    for i = 1:T 
        Trajectory_show=get(handles.trajectory, 'value');       %检测轨迹显示控件的Value值
%         if  isempty(M)          %如果小车初始化个数为空
%             warndlg('初始化错误','Input Error');
%             set(handles.Car_Number, 'Enable', 'on');  %开启【小车个数】按钮
%             break;
%         end
        if Run_Stop == 1                            %开始模式
            %set(handles.xianshi,'String','Hello');
            pause on;
%             set(handles.Car_Number, 'Enable', 'off');  %禁用【小车个数】按钮
        elseif Run_Stop == 0                        %停止模式
            %set(handles.xianshi,'String','Hi');
            velmsg.Linear.X = 0 ;
            velmsg.Linear.Y = 0 ;
%             if Run_Stop == 2                        %退出模式
%                 set(handles.Car_Number, 'Enable', 'on');  %开启【小车个数】按钮
%                 break;
%                 end
%         else
%             mode = 0;
%             Car_Number(f,M,mode,handles);
%             set(handles.Car_Number, 'Enable', 'on');  %开启【小车个数】按钮
%             break;
        end   
        
        send(robot,velmsg);                     %发布ROS小海龟的cmd_vel速度信息 
        posedata = receive(posesub);              %接受ROS小海龟的pose坐标信息
        
        set(handles.pose_x,'String',posedata.X);
        set(handles.pose_y,'String',posedata.Y);
        set(handles.pose_Theta,'String',posedata.Theta);
        
        if Control_Auto == 1                            %自主模式
            Control_flag = 0;
            dx1 = f(m).x - Eright;  %用于计算斥力的方向
            dx2 = f(m).x - Eleft;
            if abs(dx1) < abs(dx2)
            dx = dx1;
            else
            dx = dx2;
            end
            %当与边界距离小于f(m).R时，无论速度方向如何，都要产生斥力
            if abs(dx)<f(m).Obstacle_R
            vrx = f(m).k1 * (f(m).Obstacle_R - abs(dx)) * dx/abs(dx);
            else
            vrx = 0;
            end
            %计算纵向边界斥力        
            dy1 = f(m).y - Etop;
            dy2 = f(m).y - Ebottom;
            if abs(dy1) < abs(dy2)
            dy = dy1;
            else
            dy = dy2;
            end
            %当与边界距离小于f(m).R时，无论速度方向如何，都要产生斥力
            if abs(dy)<f(m).Obstacle_R
            vry = f(m).k1 * (f(m).Obstacle_R - abs(dy)) * dy/abs(dy);
            else
            vry = 0;
            end  

            f(m).vx = V * cos(Th(m));
            f(m).vy = V * sin(Th(m));

            VX(m) =  (f(m).vx  + vrx ) ;
            VY(m) =  (f(m).vy  + vry ) ;

            if (VX(m) >= 0)                    %第一、四象限
            Th(m) = atan(VY(m) / VX(m));
            else                                %第二、三象限
            Th(m) = pi + atan(VY(m) / VX(m));
            end

            velmsg.Linear.X = VX(m) ;
            velmsg.Linear.Y = VY(m) ;    
        else
            if (Control_flag == 0)
                velmsg.Linear.X = 0;
                velmsg.Linear.Y = 0;
            end
            Control_flag = 1 ;
        end

        f(m).x = double(posedata.X);
        f(m).y = double(posedata.Y);

        X1(m,i) = f(m).x ;
        Y1(m,i) = f(m).y ;
        %更新目标的位置信息

        %     f(m).x = X1(m,i);
        %     f(m).y = Y1(m,i);

        %智能体运动轨迹的动画设置
        addpoints(f(m).h,f(m).x, f(m).y);
        %智能体标记的动画设置
        p(m).XData = f(m).x;
        p(m).YData = f(m).y;
        if Trajectory_show                              %当轨迹显示控件的Value值为1时，表示轨迹开启关闭            
            delete(f(m).h);
            %f(m).h = animatedline('Color','blue','LineStyle','-','LineWidth',3);
            f(m).h = animatedline;      %创建一个动态线条对象，非常重要('MaximumNumPoints',20)
            f(m).h.LineStyle = ':';
            f(m).h.LineWidth = 2;
            f(1).h.Color = 'blue';
        end 
    end   
    set(handles.run_stop, 'String','暂停');  %设置本按钮文本为“关闭串口”
%     set(handles.Car_Number, 'Enable', 'on');  %开启【小车个数】按钮
else
    send(robot,velmsg);                     %发布ROS小海龟的cmd_vel速度信息 
    velmsg.Linear.X = 0;
    velmsg.Linear.Y = 0;
    hg = get(gca,'children');
    delete(hg);
    %------------------------Cover01t.m程序初始化参数----------------------------
    pos = [0 0 11 11];        %[x y w h]
    h = rectangle('Position',pos);
    h.LineWidth = 2;
    %画长方形必不可少的语句，没有就无法显示。
    axis([0 11 0 11]);
    axis equal;
    ax = gca;
    ax.XMinorTick = 'on';        ax.YMinorTick = 'on';
    ax.XMinorGrid = 'on';        ax.YMinorGrid = 'on';
    hold off
%     velmsg.Angular.Z = 1;
%     velmsg.Linear.X = 0;
    %-------------------------------------------------------------------------
    Run_Stop = 2;
end

function run_stop_Callback(hObject, eventdata, handles)
% hObject    handle to run_stop (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB/home/cjhtzhh/视频/MATLAB_ROS小海龟.mp4
% handles    structure with handles and user data (see GUIDATA)
global Run_Stop;
if get(hObject, 'value')
    Run_Stop = 0;
    set(hObject, 'String', '暂停');  %设置本按钮文本为“暂停”
else
    Run_Stop = 1;
    set(hObject, 'String', '运行');  %设置本按钮文本为“关闭串口”
end


function plotAD_CreateFcn(hObject, eventdata, handles)
% hObject    handle to plotAD (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: place code in OpeningFcn to populate plotAD


% --- Executes on button press in Pattern.
function Pattern_Callback(hObject, eventdata, handles)
global Control_Auto;
if get(hObject, 'value')
    Control_Auto = 0;
    set(hObject, 'String', '手动');  %设置本按钮文本为“暂停”
else
    Control_Auto = 1;
    set(hObject, 'String', '自主');  %设置本按钮文本为“关闭串口”
end
